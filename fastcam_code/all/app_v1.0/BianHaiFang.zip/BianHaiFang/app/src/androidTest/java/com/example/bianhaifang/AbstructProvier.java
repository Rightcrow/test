package com.example.bianhaifang;

import java.util.List;

public interface AbstructProvier {
    public List<Video> getList();
}
