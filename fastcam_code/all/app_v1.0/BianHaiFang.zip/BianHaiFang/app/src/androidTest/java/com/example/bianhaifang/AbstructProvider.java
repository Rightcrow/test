package com.example.bianhaifang;

public interface AbstructProvider {
}
