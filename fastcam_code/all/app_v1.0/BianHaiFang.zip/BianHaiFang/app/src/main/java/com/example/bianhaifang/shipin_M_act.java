package com.example.bianhaifang;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
//import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
//import android.support.v7.widget.RecyclerView;


import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.telecom.Connection;
import android.text.TextUtils;

import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;



import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class shipin_M_act extends AppCompatActivity {
    private Map<String, List<Video>> AllList;
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView mRecyclerView;
  //  private Map<String, List<Video>> AllList;
    private RelativeLayout actionbar;
    private ImageView img_album_arrow;
    private TextView select_video;
    private Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipin_mact);
        AbstructProvider provider = new VedioProvider(this);
        //获取所有数据
        List<Video> list = (List<Video>) provider.getList();
        adapter = new Adapter(R.layout.adapter_select_video_item, list);

        ArrayList<Video> itemBeans = new ArrayList<>();
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
         mRecyclerView.setAdapter(adapter);

    }
    DefaultBaseActivity defaultBaseActivity;
    class Adapter extends BaseQuickAdapter<Video,BaseViewHolder> {

        public Adapter(int layoutResId, List<Video> data) {
            super(layoutResId, data);
        }
        @Override
        protected void convert(BaseViewHolder helper, Video item) {
            String hms = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(item.getDuration()),
                    TimeUnit.MILLISECONDS.toMinutes(item.getDuration()) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(item.getDuration())),
                    TimeUnit.MILLISECONDS.toSeconds(item.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(item.getDuration())));

            helper.setText(R.id.text_duration, hms);
            ImageView simpleDraweeView = AdapterUtils.getAdapterView(helper.getView(R.id.simpleDraweeView), R.id.simpleDraweeView);
            int width = (MyApplication.getInstance().getScreenWidth() - 4) / 4;
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(width, width);
            simpleDraweeView.setLayoutParams(layoutParams);

            Glide
                    .with(defaultBaseActivity.context)
                    .load(Uri.fromFile(new File(item.getPath())))
                    .asBitmap()
                    .into(simpleDraweeView);
        }

    }
}