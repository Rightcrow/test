package com.example.bianhaifang;

/**
 * Created by Wxcily on 15/10/31.
 * 应用全局常量文件
 */
public class AppConstant {
    //WHAT 0-10 预留值
    public interface WHAT {
        int SUCCESS = 0;
        int FAILURE = 1;
    }
}
