package com.example.bianhaifang;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {

    public static final int DEVICE_CONNECTING = 1;//有设备正在连接热点
    public static final int DEVICE_CONNECTED  = 2;//有设备连上热点
    public static final int SEND_MSG_SUCCSEE  = 3;//发送消息成功
    public static final int SEND_MSG_ERROR    = 4;//发送消息失败
    public static final int GET_MSG           = 6;//获取新消息

    private TextView text_state;
    private ConnectThread connectThread;
    private ListenThread listenerThread;
    /**
     * 热点名称
     */
    private static final String WIFI_HOTSPOT_SSID = "TEST";
    private static final int    PORT              = 54321;
    private WifiManager wifiManager;

    private TextView status_init;

    private Button button_canshu;
    private Button button_shoujimulu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_canshu = findViewById(R.id.canshusheding);
        button_shoujimulu = findViewById(R.id.shoujimulu);
        button_canshu.setOnClickListener(l);
        button_shoujimulu.setOnClickListener(l);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        //检查Wifi状态
        if (!wifiManager.isWifiEnabled())
            wifiManager.setWifiEnabled(true);
        text_state = (TextView) findViewById(R.id.text_state);
//        status_init = (TextView) findViewById(R.id.status_init);

        //        开启连接线程
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Socket socket = new Socket(getWifiRouteIPAddress(MainActivity.this), PORT);
                    connectThread = new ConnectThread(socket, handler);
                    connectThread.start();
                    System.out.println(getWifiRouteIPAddress(MainActivity.this));
                } catch (IOException e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            text_state.setText("通信连接失败");
                        }
                    });

                }
            }
        }).start();
        listenerThread = new ListenThread(PORT, handler);
        listenerThread.start();
    }

    View.OnClickListener l = new View.OnClickListener() {

        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public void onClick(View view) {
            switch (view.getId()){
                case R.id.canshusheding:
                    Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(intent);
                    break;
                case R.id.shuaxinliulan:
                    break;
                case R.id.xiangjimulu:
                    break;
                case R.id.shoujimulu:
                    Intent intent4 = new Intent(MainActivity.this,shipin_M_act.class);
                    intent4.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(intent4);
                    break;
                case R.id.yaokongpaizhao:
                    break;
                case R.id.yaokongluxiang:
                    break;
                default:
                    break;
            }
        }
    };

    /**
     * wifi获取 已连接网络路由  路由ip地址
     * @param context
     * @return
     */
    private static String getWifiRouteIPAddress(Context context) {
//        WifiManager wifi_service = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
//        DhcpInfo dhcpInfo = wifi_service.getDhcpInfo();
//        //        WifiInfo wifiinfo = wifi_service.getConnectionInfo();
//        //        System.out.println("Wifi info----->" + wifiinfo.getIpAddress());
//        //        System.out.println("DHCP info gateway----->" + Formatter.formatIpAddress(dhcpInfo.gateway));
//        //        System.out.println("DHCP info netmask----->" + Formatter.formatIpAddress(dhcpInfo.netmask));
//        //DhcpInfo中的ipAddress是一个int型的变量，通过Formatter将其转化为字符串IP地址
//        String routeIp = Formatter.formatIpAddress(dhcpInfo.gateway);
//        Log.i("route ip", "wifi route ip：" + routeIp);

                Context mycontext = context.getApplicationContext();
        if(mycontext == null)
        {
            throw new NullPointerException("上下文 context is null");
        }
        WifiManager wm1 = (WifiManager) mycontext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if(wm1.isWifiEnabled())
        {
            int ipadrs = wm1.getConnectionInfo().getIpAddress();
            if(ipadrs == 0)
            {
                return "未获取ip地址";
            }else
            {
                String ip = ((ipadrs & 0xff)+"."+(ipadrs>>8 & 0xff)+"." +(ipadrs>>16 & 0xff)+"."+(ipadrs>>24 & 0xff));
                return ip;
            }
        }
        return "wifi未连接";

       // return routeIp;
    }
    private Handler handler = new Handler(Looper.myLooper()) {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case DEVICE_CONNECTING:
                    connectThread = new ConnectThread(listenerThread.getSocket(), handler);
                    connectThread.start();
                    break;
                case DEVICE_CONNECTED:
                    text_state.setText("设备连接成功");
                    break;
                case SEND_MSG_SUCCSEE:
                    text_state.setText("发送消息成功:" + msg.getData().getString("MSG"));
                    break;
                case SEND_MSG_ERROR:
                    text_state.setText("发送消息失败:" + msg.getData().getString("MSG"));
                    break;
                case GET_MSG:
                    text_state.setText("收到消息:" + msg.getData().getString("MSG"));
                    break;
            }
        }
    };



}