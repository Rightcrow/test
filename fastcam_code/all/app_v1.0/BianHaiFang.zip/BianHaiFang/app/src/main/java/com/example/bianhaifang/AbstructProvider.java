package com.example.bianhaifang;

import java.util.List;

public interface AbstructProvider {
    public List<Video> getList();
}
