package com.example.bianhaifang;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.telecom.Connection;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

@RequiresApi(api = Build.VERSION_CODES.M)
public class MainActivity2 extends AppCompatActivity {
    private Spinner moshi;
    private Spinner tuxiang;
    private Spinner luxiang;
    private Spinner paizhaozhangshu;
    private Spinner luxiangshijian;
    private Spinner jiangeshijian;
    private Spinner hongwailingmindu;
    private Spinner shijianchuo;
    private TextView textView_moshi;
    private TextView textView_tuxiang;
    private TextView textView_luxiang;
    private TextView textView_paizhaozhangshu;
    private TextView textView_luxiangshijian;
    private TextView textView_jiangeshijian;
    private TextView textView_hongwailingmindu;
    private TextView textView_shijianchuo;
    private ImageButton back_btn;
    private Button yulan_btn;
    private Button shezhi_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        moshi = findViewById(R.id.moshi_spinner);
        tuxiang = findViewById(R.id.tuxiang_spinner);
        luxiang = findViewById(R.id.luxiang_spinner);
        paizhaozhangshu = findViewById(R.id.zhangshu_spinner);
        luxiangshijian = findViewById(R.id.shijian_spinner);
        jiangeshijian = findViewById(R.id.jiange_spinner);
        hongwailingmindu = findViewById(R.id.hongwai_spinner);
        shijianchuo = findViewById(R.id.shijianchuo_spinner);

        textView_moshi = findViewById(R.id.moshi_text);
        textView_tuxiang = findViewById(R.id.tuxiang_text);
        textView_luxiang = findViewById(R.id.luxiang_text);
        textView_paizhaozhangshu = findViewById(R.id.zhangshu_text);
        textView_luxiangshijian = findViewById(R.id.shijian_text);
        textView_jiangeshijian = findViewById(R.id.jiange_text);
        textView_hongwailingmindu = findViewById(R.id.hongwai_text);
        textView_shijianchuo = findViewById(R.id.shijianchuo_text);

        back_btn = findViewById(R.id.back);
        yulan_btn = findViewById(R.id.yulan);
        shezhi_btn = findViewById(R.id.shezhi);



        moshi.setOnItemSelectedListener(l);
        tuxiang.setOnItemSelectedListener(l);
        luxiang.setOnItemSelectedListener(l);
        paizhaozhangshu.setOnItemSelectedListener(l);
        luxiangshijian.setOnItemSelectedListener(l);
        jiangeshijian.setOnItemSelectedListener(l);
        hongwailingmindu.setOnItemSelectedListener(l);
        shijianchuo.setOnItemSelectedListener(l);
        back_btn.setOnClickListener(l_back);
    }
    //模式下拉菜单选择监听
    AdapterView.OnItemSelectedListener l = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String content = adapterView.getItemAtPosition(i).toString();
            switch (adapterView.getId()){
                case R.id.moshi_spinner:
                    textView_moshi.setText(content);
                    break;
                case R.id.tuxiang_spinner:
                    textView_tuxiang.setText(content);
                    break;
                case R.id.luxiang_spinner:
                    textView_luxiang.setText(content);
                    break;
                case R.id.zhangshu_spinner:
                    textView_paizhaozhangshu.setText(content);
                    break;
                case R.id.shijian_spinner:
                    textView_luxiangshijian.setText(content);
                    break;
                case R.id.jiange_spinner:
                    textView_jiangeshijian.setText(content);
                    break;
                case R.id.hongwai_spinner:
                    textView_hongwailingmindu.setText(content);
                    break;
                case R.id.shijianchuo_spinner:
                    textView_shijianchuo.setText(content);
            }
        }
        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    };
    View.OnClickListener l_back = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(MainActivity2.this,MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);
        }
    };






}